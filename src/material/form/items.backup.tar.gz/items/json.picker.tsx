import React from 'react'
import DateFnsUtils from '@date-io/date-fns'
import {
  MuiPickersUtilsProvider,
  DatePicker,
  TimePicker
} from '@material-ui/pickers'
import { makeStyles, createStyles } from '@material-ui/core'
import StateFormItem, { getStoredValue, getLocallyStoredValue } from './items.controller'
import { connect } from 'react-redux'
import { IState } from '../../../interfaces'
import StateForm from '../../../state/forms/form.controller'

const useStyles = makeStyles(() =>
  createStyles({
    field: {
      width: '200px',
      margin: '0 10px'
    }
  })
)

const mapStateToProps = (state: IState) => ({
  formsData: state.formsData
})

interface IParentState {
  state: any
  setState: Function
}

interface IProps {
  def: StateFormItem<StateForm>
  formsData: any
  state?: IParentState
}

export default connect(mapStateToProps)(

function ({ def, formsData, state }: IProps) {
  const classes = useStyles()
  const { name, onChange } = def
  const getValueFromParent = () => {
    if (state) {
      return getLocallyStoredValue(state.state.formData, def)
    }
  }
  const getValue = () => {
    return getStoredValue(formsData, def.parent.name, def.name)
    || getValueFromParent()
    || null
  }
  const value = getValue()
  // json.format = json.format || 'MM/dd/yyyy'

  return (
    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <DatePicker
        className={classes.field}
        label='Date'
        id={`date-${def.id}`}
        value={value}
        onChange={onChange(name)}
        KeyboardButtonProps={{'aria-label': 'change date',}}
      />
      <TimePicker
        className={classes.field}
        label='Time'
        id={`time-${def.id}`}
        value={value}
        onChange={onChange(name)}
        format='h:mm a'
        KeyboardButtonProps={{'aria-label': 'change time',}}
      />
    </MuiPickersUtilsProvider>
  )

})
