import { IStateFormItemCustom, IRedux } from '../../../interfaces'
import StateController from '../../../controllers/state.controller'
import StateFormItem from './items.controller'

export default class StateFormItemCustom<T = any>
    extends StateController implements IStateFormItemCustom {

  private has: IStateFormItemCustom<T>
  private parentDef: StateFormItem
  private hasItems: T[]
  private hasCallback?: ((redux:IRedux)=>(e:any)=>void)
  private hasClasses: any

  constructor (has: IStateFormItemCustom<T>, parent: StateFormItem) {
    super()
    this.parentDef = parent
    this.has = has
    this.hasItems = this.has.items || []
    this.hasCallback = this.has.callback
    this.hasClasses = this.has.classes || {}
  }

  get state () { return this.has }

  get patched (): IStateFormItemCustom {
    throw new Error(`'Patched custom form item' NOT implemented.`)
  }

  get parent() { return this.parentDef }

  get callback() { return this.hasCallback }

  get classes() { return this.hasClasses }
  
  get content() { return this.has.content || '' }

  get color() { return this.has.color }

  get defaultValue() { return this.has.defaultValue || '' }

  get faIcon() { return this.has.faIcon || '' }

  get icon() { return this.has.icon || '' }

  get iconPosition() { return this.has.iconPosition }

  get items() { return this.hasItems }

  get label() { return this.has.label || '' }

  get regex() { return this.has.regex || '' }

  get route() { return this.has.route || '' }

  get text() { return this.has.text || '' }

  get title() { return this.has.title || '' }

  /**
   * Material UI component attribute.  
   * __Note__: Can be undefined on purpose.
   */
  get variant() { return this.has.variant }

  /**
   * to be used with `load` when loading `meta`. e.g.
   * ```ts
   * const meta = stateMeta['load']['key']
   * ```
   */
  get key() { return this.has.key || '' }

  /**
   * Name of internally defined callback to be executed
   */
  get handle() { return this.has.handle || '' }

  /**
   * Load metadata into field from `state.meta`. The metadata will be
   * identified by the endpoint (this value). If the data is missing, the
   * normal data source will be used.
   * ```ts
   * const meta = stateMeta['load']['key']
   * ```
   */
  get load() { return this.has.load || '' }

  /**
   * Material UI adornments.
   *
   * This field should be ignored if using another lib.
   */
  get adornment() { return this.has.adornment }

  set callback(cb: ((redux:IRedux)=>(e:any)=>void)|undefined) { this.hasCallback = cb }

  /**
   * Set custom classes for your field.
   *
   * @param classes can be an array of strings, a string, or any other means to
   *                store class names
   */
  set classes(classes: any) { this.hasClasses = classes }

}
